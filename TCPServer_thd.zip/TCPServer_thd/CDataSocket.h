﻿#pragma once

// CDataSocket 명령 대상

class CTCPServerthdDlg;

class CDataSocket : public CSocket
{
public:
	CDataSocket(CTCPServerthdDlg* pDlg);
	virtual ~CDataSocket();
	CTCPServerthdDlg* m_pDlg;
	void OnReceive(int nErrorCode);
	void OnClose(int nErrorCode);
};



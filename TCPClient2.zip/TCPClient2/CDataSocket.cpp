#include "pch.h"
#include "CDataSocket.h"
#include "TCPClient2Dlg.h"

CDataSocket::CDataSocket(CTCPClient2Dlg* pDlg)
{
	m_pDlg = pDlg;
}

CDataSocket::~CDataSocket()
{

}
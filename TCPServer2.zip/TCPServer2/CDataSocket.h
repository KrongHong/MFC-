#pragma once
#include <afxsock.h>

class CTCPServer2Doc;

class CDataSocket :   public CSocket
{
public:
	CDataSocket(CTCPServer2Doc* pDoc);
	virtual ~CDataSocket();
	CTCPServer2Doc* m_pDoc;
	void OnReceive(int nErrorCode);
	void OnClose(int nErrorCode);
};

